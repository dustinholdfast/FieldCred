# Handoff: FieldCred Gate — mobile companion app (site scan-in & credential validation)

## Overview

A mobile companion app for FieldCred (fieldcred.co) used **at the gate of a job site**: a guard or supervisor scans a worker's badge QR (or looks them up by name) and gets an immediate, fail-closed clearance verdict against that site's required credential types. Two modes:

- **Guard mode** — kiosk-style, PIN-locked: one giant scan target, verdict screens, manual lookup. For a shared device at the gate.
- **Supervisor mode** — behind a PIN: today's scan stats, the site scan log, site requirements, site re-pairing, and a way back to guard mode.

Target distribution: **Google Play Store**. The existing FieldCred web app already ships to Play as a **Trusted Web Activity** (see `android/twa-manifest.json` and `android/README.md` in the main repo) — the recommended path is to build this companion as part of the same no-build vanilla-JS PWA codebase and ship it the same way (either as new routes in the existing TWA, or a second TWA pointed at a `gate.` subdomain/route). Details below.

## About the Design Files

The files in this bundle are **design references created in HTML** — interactive prototypes showing intended look and behavior, not production code to copy directly. The task is to **recreate these designs in the FieldCred codebase's existing environment**: vanilla JS ES modules, no build step, hash-based routing, one render function per page (`js/pages/*.js`), shared components in `js/components/`, Supabase backend. Do not port the prototype's React-ish runtime; translate each screen into the repo's existing page-module pattern.

- `FieldCred Gate.dc.html` — the full clickable prototype (all screens, all states). **This is the source of truth.**
- `Options.dc.html` — the earlier exploration board. Options 1a/1b (verdict posters), 1e (guard home) and 1f (supervisor home) were chosen; other options are context only.

Open them in a browser to click through. The prototype simulates the camera (tap the viewfinder / chips choose a badge); production uses the repo's real scanner (`js/lib/qrScanner.js`).

## Fidelity

**High-fidelity.** Layout, spacing, type treatment, colors, copy and states are intentional and should be recreated closely. One deliberate exception: the prototype is styled with the "Modernist" design system (Archivo, red #ec3013, zero radius, 2px rules). If FieldCred's production brand (css/styles.css tokens) must win, keep the **layout, hierarchy, copy and state logic exactly as designed** and map the palette/type onto the existing FieldCred tokens — the status colors below already match the repo's `js/lib/status.js` STATUS_META.

## Reuse from the existing repo (do not rebuild these)

| Concern | Existing file | Notes |
| --- | --- | --- |
| QR camera + decode | `js/lib/qrScanner.js` | BarcodeDetector w/ jsQR fallback; keep its lifecycle handling (visibilitychange, pagehide, bfcache) from `js/pages/scan.js` |
| Clearance evaluation | `js/lib/clearance.js` | `evaluateClearance(worker, requiredTypeIds)` — fail-closed; expiring counts as met but is surfaced |
| Cert status derivation | `js/lib/status.js` | `certStatus(expiryDate)` → valid / expiring (≤60d) / expired / missing. Never store status |
| Offline cache + queued scans | `js/lib/offlineCache.js`, `js/lib/offlineSync.js` | cache worker/site records; `queueScan()` when `record_gate_scan` RPC fails |
| Gate-site pairing | localStorage key `fieldcred_gate_site` | shared with `js/pages/gateConfig.js` / `js/pages/publicRecord.js` |
| Scan audit log | `record_gate_scan()` RPC (migration 009), read via `store.siteScanLog` | server re-derives the verdict; results vocabulary: cleared / blocked / no_requirements / unknown_worker / unknown_site |
| Haptics | `buzz()` pattern in `js/pages/scan.js` | cleared = 40ms; blocked = [60,60,60]; unknown = long |
| Worker/site data | `js/lib/state.js` (`getBySlug`, `getPublicSite`) | |

The key **behavioral change vs. today's app**: today `js/pages/scan.js` navigates to the full `/r/:slug` record. This design replaces that with **dedicated full-screen verdict screens** (below). Keep the same rationale from the scan.js comments — clearance evaluation, offline fallback, and the audit log must stay in one place; move that shared logic into a module both the verdict screen and `/r/:slug` use.

## Screens / Views

All screens are full-viewport mobile (design width 412px), flex column, `overflow:auto` on the scrolling middle region. Font family: heading = Archivo 700–800, body = Archivo 400–600. Ink `#201e1d`, ground `#f3f2f2`, accent `#ec3013`. Zero border-radius everywhere. Section dividers are **2px solid ink**; row dividers 1px `rgba(0,0,0,.15)`.

### 1. Guard home (`guardHome`)

Purpose: idle state of the shared gate device.

- **Header** (padding 18px, 2px ink bottom border): brand "FIELDCRED GATE" (800 15px, letter-spacing .08em); below, a row with kicker "CHECKING AGAINST" (mono 9.5px, letter-spacing .1em, #5b5754) over the paired site "Eastline Terminal · Gate 2" (700 14px), and a red underlined "CHANGE" link (700 11px, #a02310) → pairing screen.
- **Offline banner** (only when offline): bg `#f8efdc`, 2px `#c98a12` bottom border, 9px/18px padding, 600 11px `#8a6d1a`: "● OFFLINE — verdicts use cached data from 06:12 AM. N scans queued to sync."
- **Scan target**: fills remaining height, ink `#201e1d` block; centered 150×150 reticle of four 30×30 corner brackets, 3px solid `#ec3013`; bottom-left label "TAP TO SCAN A BADGE →" (700 16px white, letter-spacing .04em). Hover/pressed: bg `#2c2a28`.
- **Secondary action**: "LOOK UP BY NAME →" — 2px ink border, 14px/16px padding, 700 13px ink, label flush left, arrow right. Hover bg `#e8e6e3`.
- **Footer** (1px top divider): "DEVICE LOCKED TO GATE MODE · SUPERVISOR PIN TO EXIT →" (mono 9.5px #5b5754) → PIN screen.

### 2. Scanner (`scanner`)

Dark screen (`#201e1d`).

- Top bar: "SCAN BADGE" white 800 13px; "CLOSE" white underlined right → home.
- Context strip (1px white/.2 bottom border): mono 10px white/.65 "CHECKING AGAINST EASTLINE TERMINAL · GATE 2" (prefixed "● OFFLINE · " when offline).
- Viewport: camera feed fills; 190×190 reticle (36px corner brackets, 3px `#ec3013`) with an animated horizontal scan line (2px `#ec3013`, 2.6s ease-in-out loop, 6%→88% top). Bottom-left hint (11.5px white/.7): "Point the camera at the QR on the worker's badge…"
- Prototype-only: the "SIMULATE A BADGE" chip strip at the bottom. **Omit in production** — the real camera decodes.
- On decode: haptic buzz, then verdict screen. Camera lifecycle: copy `js/pages/scan.js` teardown behavior exactly.

### 3. Verdict — CLEARED (`vCleared`)

Light ground. Top bar as guard home ("CLOSE" → home).

- Kicker: "SCAN RESULT · 06:42 AM" (mono 11px, .1em, #5b5754). Manual lookups say "MANUAL LOOKUP" instead.
- Headline: "CLEARED" — 800 56px/0.95, letter-spacing -.02em, **green `#158060`**.
- 2px ink rule.
- Worker row: 56×56 ink square with white initials (800 20px), name 700 18px ink, subline "{title} · {dept}" 12.5px #5b5754.
- "REQUIRED FOR {SITE}" kicker, then one row per required credential the worker holds: cert name (600 12.5px ink) left, status tag right in mono 10px — "VALID · 2028" in `#158060` or "EXPIRING · AUG 15" in `#c98a12`. 1px row dividers.
- If any required cert is expiring: note "⌁ {names} expiring within 60 days — still met today." (11px `#8a6d1a`).
- If offline: "● Verdict from cached data (06:12 AM) — confirm another way if you can."
- Footer: audit line "✓ LOGGED TO SITE LOG · HAPTIC: SHORT BUZZ" (mono 10px #5b5754) — when offline, "✓ QUEUED FOR SITE LOG"; then primary button **"SCAN NEXT →"** — solid ink, white 700 15px, label flush left, 16px/18px padding → scanner.

### 4. Verdict — NOT CLEARED (`vBlocked`)

**Entire screen is accent red `#ec3013`** — the poster statement; all chrome white.

- Top bar: white text, 2px white bottom border.
- Headline: "NOT CLEARED" on two lines — 800 50px/0.95 white.
- 2px white rule; worker row with **white square avatar, red initials**.
- "MISSING FOR {SITE}" kicker (mono 10px white/.75), then one row per missing type (1px white/.4 dividers, 700 14px white): "✕ Confined Space Entry — not on file" or "✕ Rigging & Signaling — expired MAY 12" (use the expired cert's date when one exists).
- Guidance line (11.5px white/.85): "Direct the worker to their supervisor. This scan was logged as blocked."
- Footer: "✓ LOGGED TO SITE LOG · HAPTIC: DOUBLE BUZZ"; button "SCAN NEXT →" — **white fill, ink text** (hover `#f0ede9`).

### 5. Verdict — UNRECOGNIZED BADGE (`vUnknown`)

Light ground; headline "UNRECOGNIZED BADGE" in amber `#c98a12` (800 44px/0.98, two lines). Body copy (13px ink, max-width 320px): "This QR isn't a FieldCred badge for this organization — or the record was removed. Check the badge, or look the worker up by name." Outlined "LOOK UP BY NAME →" button. Footer: "✓ LOGGED TO SITE LOG · HAPTIC: LONG BUZZ" + ink "SCAN AGAIN →". Logged as `unknown_worker`.

### 6. Manual lookup (`lookup`)

- Top bar "LOOK UP BY NAME" / "CLOSE".
- Search field: 2px ink border, white bg, 12px/14px padding, 600 14px, **radius 0**, placeholder "Worker name…". Under it (10.5px #5b5754): "Manual lookups get the same clearance check and are logged the same way."
- Result rows (1px dividers): 40×40 ink initials square, name 700 14px, "{title} · {dept}" 11.5px #5b5754, trailing mono "CHECK →". Tap → same verdict flow, kicker "MANUAL LOOKUP".
- Empty state: `No workers match "{query}".`
- Production: search the tenant directory via `store` (auth required for directory search — decide whether guard-mode lookup searches only the paired site's roster; recommended).

### 7. Site pairing (`pairing`)

- Top bar "PAIR TO A SITE" / "CLOSE".
- Explainer (12px #5b5754): "In the field, pair by scanning the QR posted at the gate. Verdicts on this device are then checked against that site's requirements — set once, kept offline."
- One card per site: 2px ink border, name + gate 700 14px, "Requires: {type names}" 11px #5b5754; the currently paired card gets bg `#e8e6e3` and a "PAIRED" tag (ink bg, white mono 9.5px). Tap pairs and returns home.
- Production: pairing is normally done by scanning the site gate QR (`/gate/:slug` flow, localStorage `fieldcred_gate_site`); the in-app list is the supervisor-facing alternative and should require auth.

### 8. Supervisor PIN (`pin`)

- Top bar "SUPERVISOR PIN" / "CANCEL".
- Copy: "Enter the supervisor PIN to leave gate mode." Four 16×16 squares, 2px ink border, filled ink as digits are entered.
- Keypad: 3-column grid, gap 10px; keys 2px ink border, 800 18px, 16px vertical padding; pressed state inverts to ink/white. Keys 1-9, ⌫, 0.
- Auto-submit at 4 digits. Wrong PIN → clear + error (600 11px `#ec3013`): "Wrong PIN — try again."
- Production: PIN belongs to the device's supervisor session (see `js/lib/roles.js`); prototype hardcodes 1234 — replace.

### 9. Supervisor home (`supHome`, tab HOME)

- Header (2px ink border): "FIELDCRED" 800 15px + "{site} · {user name}, {role}" 11px #5b5754; right, 36×36 ink initials square.
- Stats row: one bordered strip (2px ink) split into three equal cells with 2px ink internal dividers: SCANS TODAY (ink), CLEARED (`#158060`), BLOCKED (`#ec3013`) — value 800 24px, label mono 9.5px.
- Primary: "SCAN A BADGE →" — **solid accent `#ec3013`**, white 700 15px, flush-left label (hover `#c92a10`).
- "RECENT SCANS · GATE 2" kicker + last 5 log rows: "{time} · {name}" 600 12.5px left; result tag right — mono 9.5px, 3px/7px padding: CLEARED `#e4f3ec`/`#158060`, BLOCKED `#f9e8e5`/`#b23a2e`, UNRECOGNIZED `#f8efdc`/`#8a6d1a`.
- **Tab bar** (2px ink top border, 4 equal cells, 2px ink dividers, 800 11px, 13px vertical padding): HOME · LOOKUP · LOG · SITE. Active tab inverts (ink bg, white text). LOOKUP opens the lookup screen.

### 10. Supervisor — LOG tab

Title "Scan log" 800 18px; subline: "Every scan at this gate — cleared, blocked, or unrecognized — is written to the site audit log the moment it happens." Full log list (same row treatment as recent scans) with a "Missing: {types}" second line in `#b23a2e` on blocked rows. When offline with queued scans: "● N offline scans queued — will sync to the site log when back online." (600 10.5px `#8a6d1a`).
Production source: `store.siteScanLog(siteId)` — same data as `js/pages/siteScanLog.js`.

### 11. Supervisor — SITE tab

Site name 800 18px; "REQUIRED CREDENTIAL TYPES" kicker; list of required types (600 13px rows). Explainer: "A worker is cleared only when every required type is met by a valid or expiring credential — never an expired one, never one with no date." Buttons: outlined "CHANGE PAIRED SITE →" and solid-ink "RETURN TO GATE MODE →".

## Interactions & Behavior

- **Navigation**: guardHome ⇄ scanner ⇄ verdict; guardHome → lookup / pairing / pin; pin → supHome; supHome tabs; supHome → scanner (verdict returns to the mode's home on CLOSE, back to scanner on SCAN NEXT).
- **Verdict derivation** (must match `js/lib/clearance.js`): for each required type, the best cert of that type wins — valid ▸ met; expiring ▸ met + warned; expired/no-date/absent ▸ missing. Any missing type ⇒ NOT CLEARED. No requirements set ⇒ show the site-neutral notice (see repo `gateBannerHtml`), never a blanket "cleared".
- **Every check is logged** — scan or manual lookup, cleared or not — via `record_gate_scan()`; on network failure, `queueScan()` and show "QUEUED FOR SITE LOG".
- **Haptics**: cleared 40ms; blocked [60,60,60]; unknown long. Silent no-op where unsupported.
- **Offline**: banner on homes + scanner strip prefix; verdicts add the cached-data note; queued counter increments; sync via existing `offlineSync.js` drain. Fail-closed when nothing is cached (copy the `/r/:slug` "record isn't available" logic).
- **Hover/pressed**: light surfaces tint to `#e8e6e3`; ink surfaces to `#2c2a28`; accent to `#c92a10`; focus-visible ring 2px `#ec3013` offset 2px.
- **Scan-line animation**: 2.6s ease-in-out infinite vertical sweep.
- **PIN**: auto-submit at 4 digits; error shakes are optional, clearing + message is required.

## State Management

- `mode`: 'guard' | 'supervisor' (persist per device; guard is default after pairing).
- `screen`: guardHome | scanner | verdict | lookup | pairing | pin | supHome (+ supTab: home | log | site).
- `pairedSiteSlug`: localStorage `fieldcred_gate_site` (existing key — do not rename).
- `verdict`: { kind, worker, met[], expiring[], missing[], time, via: 'scan'|'lookup' }.
- `offline`: derived from fetch failures (as in publicRecord.js), not navigator.onLine alone.
- `queuedScans`: count of entries in the offline scan queue.
- Data fetching: `store.getBySlug(slug)`, `store.getPublicSite(gateSlug)`, `store.siteScanLog(siteId)` — all existing.

## Design Tokens

Colors: ink `#201e1d` · ground `#f3f2f2` · surface-hover `#e8e6e3` · accent `#ec3013` (pressed `#c92a10`) · accent-deep `#a02310` · muted text `#5b5754` · valid `#158060` on `#e4f3ec` · expiring `#c98a12` / text `#8a6d1a` on `#f8efdc` · expired `#b23a2e` on `#f9e8e5` · row divider `rgba(0,0,0,.15)`.
Type: Archivo throughout; display 44–56px/0.95–0.98 800; titles 14–18px 700–800; body 11–14px 400–600; kickers/tags: monospace 9.5–11px, letter-spacing .08–.1em, uppercase.
Radius: **0 everywhere.** Rules: 2px ink for section/major borders, 1px rgba(0,0,0,.15) for rows. Spacing: 18px screen padding; 14–16px control padding; 10–12px row padding.
Buttons: labels **flush left**, trailing arrow right, never centered.

## Assets

No image assets. Reticle, initials squares and all iconography are pure CSS/text (✓ ✕ ● ⌁ → ⌫ characters). Production should use the FieldCred shield logo from the repo (`assets/icon.svg`, `js/components/logo.js`) in place of the text-only brand where appropriate. Icons, if added, should be Lucide.

## Play Store path

The repo already ships a TWA (`android/twa-manifest.json`, Bubblewrap). Recommended:
1. Implement the gate app as routes in the existing PWA (`#/gate-app`, or a dedicated start_url) with `manifest.webmanifest` display=standalone; it inherits the service worker (`sw.js`) and offline cache.
2. Either add a second TWA project (new applicationId, e.g. `co.fieldcred.gate`, start_url pointing at the gate home) or ship inside the existing app with a launcher shortcut. Camera permission must be declared; test BarcodeDetector on Android Chrome (primary path — jsQR is the fallback).
3. Digital Asset Links (`.well-known/assetlinks.json`) must cover the new package signature.

## Files

- `FieldCred Gate.dc.html` — clickable prototype, all screens/states (source of truth).
- `Options.dc.html` — exploration board; chosen: 1a/1b verdicts, 1e/1f homes.
- Main repo references: `js/pages/scan.js`, `js/pages/publicRecord.js`, `js/pages/gateConfig.js`, `js/pages/siteScanLog.js`, `js/lib/clearance.js`, `js/lib/status.js`, `js/lib/qrScanner.js`, `js/lib/offlineCache.js`, `js/lib/offlineSync.js`, `js/lib/roles.js`, `supabase/migrations/008_public_gate_clearance.sql`, `009_gate_scan_log.sql`, `android/`.
